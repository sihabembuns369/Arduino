This is the enclosure for the ESP32-base BLE-Scanner.
