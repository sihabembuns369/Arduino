#define GIT_VERSION "undefined"
