var indexSectionsWithContent =
{
  0: "ds",
  1: "ds"
};

var indexSectionNames =
{
  0: "all",
  1: "classes"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes"
};

